import random, math
pairs = [
"EURUSD","GBPUSD","USDJPY","AUDUSD","USDCAD","USDCHF","NZDUSD","EURJPY","GBPJPY"
]

def make_series():
    base = 1.1000 + random.random()*0.01
    closes = [base + math.sin(i/5)*0.001 + random.uniform(-0.0005,0.0005) for i in range(260)]
    return {'close': closes}

def get_all_pairs_latest():
    data = {}
    for p in pairs:
        data[p] = make_series()
    return data
