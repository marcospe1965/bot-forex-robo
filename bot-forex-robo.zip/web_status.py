from flask import Flask, render_template_string
import os
app = Flask(__name__)
STATUS = {"running": True, "last_signals": []}
@app.route("/")
def index():
    html = """
    <html><head><meta charset='utf-8'><title>Bot Forex - Status</title></head>
    <body style="font-family: Arial; text-align:center; padding:30px;">
    <h1>Bot Forex - Status</h1>
    <p><strong>Estado:</strong> {{state}}</p>
    <p><strong>Últimos sinais:</strong></p>
    <pre>{{signals}}</pre>
    </body></html>
    """
    return render_template_string(html, state=("Executando" if STATUS["running"] else "Pausado"), signals=STATUS["last_signals"])
if __name__ == '__main__':
    app.run(host='0.0.0.0', port=int(os.environ.get("PORT", 5000)))
