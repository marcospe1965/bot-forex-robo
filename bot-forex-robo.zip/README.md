# Bot Forex - pacote pronto (apenas sinais, modo demo)

Este repositório contém um robô de sinais Forex pronto para deploy no Render.
- Envia sinais somente (não opera ordens).
- Mensagens em Português com cabeçalho: [Bot Forex].
- Resumo diário automático às 22:00 (Horário de Brasília).
- Usa provider_demo.py por padrão (modo de demonstração).
