"""
Robô de Indicadores Forex - sinais apenas (envia mensagens para Telegram).
Nome exibido: Bot Forex
Resumo diário às 22:00 (Horário de Brasília).
"""

import time, yaml, datetime
from telegram_bot import send_telegram
from signals import check_signals
from provider_demo import get_all_pairs_latest
import pytz

BRAZIL_TZ = pytz.timezone("America/Sao_Paulo")
BOT_NAME = "Bot Forex"

def load_config():
    with open("config.yaml","r",encoding="utf-8") as f:
        return yaml.safe_load(f)

def send_signal(token, chat_id, pair, signal, confidence):
    tipo = "COMPRA" if signal == "BUY" else "VENDA"
    hora = datetime.datetime.now(BRAZIL_TZ).strftime("%H:%M")
    mensagem = f"💬 [{BOT_NAME}] — Sinal de {tipo} detectado em {pair}\\nConfiança: {confidence}\\nHora: {hora} (Horário de Brasília)"
    send_telegram(token, chat_id, mensagem)

def send_daily_summary(token, chat_id, summary):
    mensagem = f"📊 Relatório diário — {BOT_NAME}\\nSinais enviados: {summary['total']}\\nCompras: {summary['buy']} | Vendas: {summary['sell']}\\nPar mais ativo: {summary.get('most_active','-')}\\nHora do último sinal: {summary.get('last_time','-')}"
    send_telegram(token, chat_id, mensagem)

def main():
    cfg = load_config()
    token = cfg.get("telegram_token")
    chat_id = cfg.get("chat_id")
    last_summary_date = None
    summary = {"total":0, "buy":0, "sell":0, "per_pair":{}, "last_time": None}
    print("Robô iniciado (modo demo). Enviando sinais para Telegram em Português. Nome:", BOT_NAME)
    while True:
        try:
            data = get_all_pairs_latest()
            for pair, series in data.items():
                signal, confidence = check_signals(series)
                if signal and confidence == "Alta":
                    send_signal(token, chat_id, pair, signal, confidence)
                    summary["total"] += 1
                    if signal == "BUY":
                        summary["buy"] += 1
                    else:
                        summary["sell"] += 1
                    summary["per_pair"][pair] = summary["per_pair"].get(pair,0) + 1
                    summary["last_time"] = datetime.datetime.now(BRAZIL_TZ).strftime("%H:%M")
            now = datetime.datetime.now(BRAZIL_TZ)
            today = now.date()
            if now.hour == 22 and last_summary_date != today:
                most_active = max(summary["per_pair"].items(), key=lambda x: x[1])[0] if summary["per_pair"] else "-"
                summary_payload = {"total": summary["total"], "buy": summary["buy"], "sell": summary["sell"], "most_active": most_active, "last_time": summary.get("last_time")}
                send_daily_summary(token, chat_id, summary_payload)
                summary = {"total":0, "buy":0, "sell":0, "per_pair":{}, "last_time": None}
                last_summary_date = today
            time.sleep(60)
        except Exception as e:
            print("Erro no loop principal:", e)
            time.sleep(10)

if __name__ == '__main__':
    main()
