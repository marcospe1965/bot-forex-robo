import pandas as pd
import numpy as np

def compute_rsi(prices, period=14):
    delta = np.diff(prices)
    up = np.where(delta>0, delta, 0.0)
    down = np.where(delta<0, -delta, 0.0)
    roll_up = pd.Series(up).rolling(period).mean()
    roll_down = pd.Series(down).rolling(period).mean()
    rs = roll_up / (roll_down.replace(0, 1e-9))
    rsi = 100 - (100 / (1 + rs))
    return rsi.fillna(50)

def check_signals(series):
    df = pd.DataFrame({'close': series['close']})
    if len(df) < 210:
        return (None, None)
    df['sma50'] = df['close'].rolling(50).mean()
    df['sma200'] = df['close'].rolling(200).mean()
    rsi = compute_rsi(df['close'].values, 14)
    recent_rsi = rsi.iloc[-1]
    if df['sma50'].iloc[-1] > df['sma200'].iloc[-1] and recent_rsi < 35:
        return ('BUY', 'Alta')
    if df['sma50'].iloc[-1] < df['sma200'].iloc[-1] and recent_rsi > 65:
        return ('SELL', 'Alta')
    return (None, None)
